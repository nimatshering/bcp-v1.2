<x-app-layout>
    <div class="py-b">
      <div class="flex max-w-7xl mx-auto sm:px-6 lg:px-8 my-10 text-2xl font-extrabold uppercase justify-center">
            Bhutan Climate Portal
      </div>

      <div class="max-w-7xl mx-auto sm:px-6 md:px-10">
        <div class="bg-gray-100 overflow-hidden shadow sm:rounded-lg">
          <div class="p-4 bg-white border-b border-gray-200">
              <p class="uppercase py-2 font-bold">
                Admin Dashboard
              </p>
          </div>

           <div class="p-4 bg-white">
                Content
          </div>

          <div class="bg-white bg-opacity-25 p-4">
                 Footer
          </div>
        </div>
      </div>
    </div>
</x-app-layout>
