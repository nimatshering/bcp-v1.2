 <nav class="bg-gray-100 py-3 w-full mt-2 rounded shadow px-2 md:px-0">
    <ol class="list-reset flex text-sm pl-2">
      <li><a href="{{ route('climatescience.category')}}" class="text-blue font-bold">Climate Science and Research</a></li>
      <li><span class="mx-2">/</span></li>
      <li><a href="{{ route('climatescience.subcategory', $category->slug)}}" class="text-blue font-bold">{{ $category->name }}</a></li>
      <li><span class="mx-2">/</span></li>
      <li>{{ $subcategory->name}}</li>
    </ol>
  </nav>