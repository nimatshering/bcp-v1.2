<footer class="relative bottom-0 bg-gray-100 py-2">
    <div class="container mx-auto px-4">
      <div class="flex flex-wrap items-center md:justify-between justify-center">
        <div class="w-full md:w-4/12 px-4 mx-auto text-center">
          <div class="text-sm text-gray-800 font-semibold py-1">
            Copyright ©2021 - NECS. All Rights Reserved
            <a href="#" class="text-gray-800 hover:text-gray-700">Thimphu, Bhutan</a>.
          </div>
        </div>
      </div>
    </div>
  </footer>
